package com.revolut.vo;

import java.util.List;

import com.revolut.model.Account;

public class Accounts {
	private List<Account> accountList;

	public List<Account> getAccountList() {
		return accountList;
	}

	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}


}
